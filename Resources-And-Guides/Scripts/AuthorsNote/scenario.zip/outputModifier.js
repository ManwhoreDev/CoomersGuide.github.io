const modifier = (text) => {
  return { text: text }
}

modifier(text)
