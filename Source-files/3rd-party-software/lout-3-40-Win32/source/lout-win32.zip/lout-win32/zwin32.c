#include <stdio.h>
#include <windows.h>

char *
LoutLib(char *errbuf, size_t bufsize)
{
    static char libdir[_MAX_PATH];
    static int once = 0;

    if (!once) {
	DWORD len;
	char *lastslash;

	ZeroMemory(libdir, _MAX_PATH);
	len = GetModuleFileName(NULL, libdir, _MAX_PATH);

	if (len == 0) {
	    FormatMessage(FORMAT_MESSAGE_FROM_SYSTEM, NULL,
			  GetLastError(),
			  MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT),
			  errbuf, bufsize,
			  NULL);
	    return NULL;
	}

	lastslash = strrchr(libdir, '\\');
	if (lastslash == NULL) {
	    _snprintf(errbuf, bufsize, "No slash in \"%s\"", libdir);
	    return NULL;
	}

	*lastslash = '\0';
    }

    return libdir;
}
